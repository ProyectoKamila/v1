TEXT_GAMEOVER  = "GAME OVER";
TEXT_PLAY      = "PLAY";
TEXT_BET       = "BET";
TEXT_WIN       = "WIN";
TEXT_MONEY     = "MONEY";
TEXT_DEAL      = "DEAL";
TEXT_BET_ONE   = "BET ONE";
TEXT_MAX_BET   = "BET MAX";
TEXT_RECHARGE  = "RECHARGE";
TEXT_EXIT      = "EXIT";
TEXT_DRAW      = "DRAW";
TEXT_NO_WIN    = "NO WIN";
TEXT_CURRENCY  = "$";
TEXT_COMBO     = new Array(
                            "Royal Flush",
                            "Straight Flush",
                            "Four of a Kind",
                            "Full House",
                            "Flush",
                            "Straight",
                            "Three of a Kind",
                            "Two Pairs",
                            "Jacks or Better"
                            )
